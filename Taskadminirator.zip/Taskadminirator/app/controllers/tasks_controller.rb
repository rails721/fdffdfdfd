class TasksController < ApplicationController
  before_action :authenticate_user!
  before_action :set_task, only: [ :show, :edit, :update, :destroy ]

  rescue_from ActiveRecord::RecordNotFound, with: :task_not_found
  def index
    @tasks = Task.all
    @tasks = Task.includes(:comments).all
  end

  def comments
    @tasks = Task.all
    @tasks = Task.includes(:comments).all
  end

  def new
    @task = Task.new
  end

  def create
    @task = current_user.tasks.build(task_params)

    if @task.save
      redirect_to tasks_path, notice: "Task was successfully created."
    else
      render :new
    end
  end

  def show
    # @tasks = Task.all
    # @tasks = Task.includes(:comments).all
    @task = Task.find(params[:id])
  end

  def edit
  end

  def update
    if @task.update(task_params)
      redirect_to tasks_path, notice: "Task was successfully updated."
    else
      render :edit
    end
  end

  def destroy
    @task.destroy
    redirect_to tasks_path, notice: "Task was successfully destroyed."
  end

  private

  def set_task
    @task = Task.find(params[:id])
  end

  def task_not_found
    flash[:alert] = "Task not found."
    redirect_to tasks_path
  end

  def task_params
    params.require(:task).permit(:task_name, :status, :task_type, comments_attributes: [ :id, :content, :_destroy ])
  end
end
