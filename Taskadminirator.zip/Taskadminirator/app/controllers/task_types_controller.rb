class TaskTypesController < ApplicationController
  def new
    @task_type = TaskType.new
    respond_to do |format|
      format.js { render "new" } # Renders the form in a modal via AJAX
    end
  end

  def create
    @task_type = TaskType.new(task_type_params)
    if @task_type.save
      respond_to do |format|
        format.js { render "create" } # Handle the successful create via AJAX
      end
    else
      respond_to do |format|
        format.js { render "new" } # If there are errors, re-render the form via AJAX
      end
    end
  end

  private

  def task_type_params
    params.require(:task_type).permit(:name)
  end
end
