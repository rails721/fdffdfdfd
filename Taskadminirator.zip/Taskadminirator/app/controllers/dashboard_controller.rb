class DashboardController < ApplicationController
  def index
    @tasks = Task.all
    @tasks = Task.includes(:comments).all
  end
end
